//Question 5
#include<stdio.h>
#include<conio.h>
void main()
{
     char M, F, gen;
     int age;
     printf("-----------------------");
     printf("\nEnter M for male");
     printf("\nEnter F for female");
     printf("\n---------------------");
     printf("\nEnter your Gender: ");
     scanf("%c",&gen);
     printf("\nEnter your age: ");
     scanf("%d",&age);
     if(gen==M && age>30)
     {
          printf("\nDriver is married.");
     }
     else{
          if(gen==F && age>25)
            printf("\nDriver is married.");
          else
            printf("\nDriver is unmarried");
     }
     getch();
}