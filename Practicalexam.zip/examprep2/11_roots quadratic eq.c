#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
    int a,b,c;
    float d,r1,r2;
    printf("Quadratic Equation: Ax^2+Bx+C=0");
    printf("\nEnter the values of A,B and C:\n");
    scanf("%d%d%d",&a,&b,&c);
    d=pow(b,2)-(4*a*c);
    if(d<0)
    {
        printf("\nNo real roots");
    }
    else
    {
        r1=-b+sqrt(d);
        r2=-b-sqrt(d);
        printf("\nThe two roots of the given equation are %f and %f",r1,r2);
    }
    getch();
}
