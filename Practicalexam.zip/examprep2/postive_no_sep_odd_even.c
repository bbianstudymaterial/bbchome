//Question 6
#include<stdio.h>
#include<conio.h>
void main()
{
    int i, n, x[50];
    printf("\n How many Number ? ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
       printf("\n Enter your %dth number: ",i+1);
       scanf("%d",&x[i]);
    }
    printf("\n---------------------");
    printf("\n Even Number \n");
    for(i=0;i<n;i++)
    {
    if(x[i]%2==0)
    {
        printf(" %d,",x[i]);
    }
    }
    printf("\n---------------------");
    printf("\n Odd number\n");
    for(i=0;i<n;i++)
    {
    if(x[i]%2!=0)
    {
        printf(" %d,",x[i]);
    }
    }
    getch();


}