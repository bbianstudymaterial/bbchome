#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char st1[50],st2[19],st[20];
    int i, j;
    printf("\nEnter first string: ");
    scanf("%s",st1);
    printf("\nEnter second string: ");
    scanf("%s",st2);
    i=0;j=0;
    while (st1[i] != '\0')
    {
        st[j] = st1[i];
        i++;
        j++;
    }

    /*add*/

    st[j] = ' ';
    j++;
    i =0;
    while (st2[i]!='\0')
    {
        st[j] = st2[i];
        i++;
        j++;
    }
    st[j]='\0';
    printf("\nResultant string is %s",st);
    getch();

    
}