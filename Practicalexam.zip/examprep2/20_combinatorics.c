#include<stdio.h>
#include<conio.h>
int fact(int);
void main()
{
    int n,r;
    float nPr,nCr;
    printf("\nEnter the value of n and r :\n");
    scanf("%d%d",&n,&r);
    if(n<r||n<0||r<0)
        printf("\nERROR!!");
    else
    {
        nPr=(fact(n)/fact(n-r));
        nCr=(fact(n)/(fact(r)*fact(n-r)));
        printf("\nThe value of nCr = %f\nThe value of nPr = %f",nCr,nPr);
    }
    getch();
}
int fact(int a)
{
    if(a==0||a==1)
        return 1;
    else
        return (a*fact(a-1));
}
