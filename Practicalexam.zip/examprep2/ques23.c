#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
int a[10][10],b[10][10],c[10][10],m,n,l,i,j,k;
void main()
{
    extern int a[10][10], b[10][10], c[10][10], m, n, l;
    void matmul();
    printf("\nEnter order of A matrix (m x n) ");
    scanf("%d %d",&m,&n);
    printf("\nEnter A matrix values \n");
    for(i=0;i<m;i++)
     for(j=0;j<n;j++)
      scanf("%d",&a[i][j]);
    printf("\nEnter order of B matrix (nxl) ");
    scanf("%d %d",&n,&l);
    printf("\nEnter B matrix values \n");
    for(i=0;i<n;i++)
     for(j=0;j<l;j++)
      scanf("%d",&b[i][j]);
    matmul(); //matmul(matrix multiplication)
    printf("\nResultant matrix is \n");
    for(i=0;i<m;i++)
     {
        for(j=0;j<l;j++)
         printf("%5d",c[i][j]);
        printf("\n");
     }
    getch();
}
void matmul()
{
    extern int a[10][10],b[10][10],c[10][10],m,n,l;
    for(i=0;i<m;i++)
     for(j=0;j<l;j++)
      {
        c[i][j] = 0;
        for(k=0;k<n;k++)
         c[i][j] = c[i][j] + a[i][k] * b[k][j];
      }
}