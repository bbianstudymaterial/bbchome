#include<stdio.h>
#include<conio.h>
int hcf(int,int);
void main()
{
    int a,b,h,lcm;
    printf("Enter two numbers:\n");
    scanf("%d%d",&a,&b);
    h=hcf(a,b);
    lcm=((a*b)/h);
    printf("\nHCF=%d\nLCM=%d",h,lcm);
    getch;
}
int hcf(int a,int b)
{
    int s,h;
    if(a<b)
        s=a;
    else
        s=b;
    for(int i=1;i<=s;i++)
    {
        if(a%i==0 && b%i==0)
            h=i;
    }
    return h;
}
