#include<stdio.h>
#include<conio.h>
#include<math.h>
float sine(int);
void main()
{
    printf("Sine function:\n");
    printf("\nsin(0)=%f\nsin(30)=%f\nsin(45)=%f\nsin(60)=%f\nsin(90)=%f",sine(0),sine(30),sine(45),sine(60),sine(90));
    getch;
}
float sine(int n)
{
    float y;
    switch(n)
    {
        case 0: y=0;
                break;
        case 30:y=1.0/2;
                break;
        case 45:y=1/(sqrt(2));
                break;
        case 60:y=(sqrt(3))/2;
                break;
        case 90:y=1;
                break;
    }
    return y;
}
